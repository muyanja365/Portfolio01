import Navbar from './components/navbar/navbar'

import './App.css'

function App() {


  return (
    <>
   <Navbar />
    </>
  )
}

export default App
