import React from 'react';

const Test = () => {
    return (
        <div>
            <h1>Test Page</h1>
            <p>This is a test page.</p>
        </div>
    );
};

export default Test;